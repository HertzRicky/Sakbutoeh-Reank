var token ='';
//LoadToket();
token = prompt("Lebokna TOKEN", "");
var mainDiv,UserMee;
var itungane =0 ;
var TargetNegara =["United States","United Kingdom","Hungary","Germany","Romania","United Kingdom","South Africa","Italy","France","Canada","Austria","Australia","Poland","Switzerland", "Greece", "New Zealand", "Denmark", "Germany", "Norway", "Sweden", "Finland", "Mexico", "Japan"] ; //NEK PPENGIN NAMBAIH TARGET NEGARA NANG KENE
	
body = document.body;
    div = document.createElement("div");
    div.id = "mumets";
    div.style.padding = "10px";
    div.style.borderRadius  = "10px";
    div.style.width  = "300px";
	div.style.height  = "350px";
    div.style.position  = "fixed";
    div.style.zIndex = "9999";
    div.style.top = "7%";
    div.style.left  = "1%";
    div.style.fontSize  = "12px";
    div.style.fontWeight  = "600";
    div.style.boxShadow  = "0 0 5px #000";
    div.style.backgroundColor = "#0880d7";
    div.innerHTML ="<h2> <span style='float:right;font-size:12px'>Hertz Firend Req</span></h2>";
	
    div.innerHTML  += "<hr style='border-top:1px solid #444'/><div style='margin-top:10px' id='divsatu'> <div style='display:inline-block;float:right'><input value='20' id='simor_val' style='width:45px;height:18px;padding:3px;font-size:12px'><button  id='simor' style='background:#4267B2;color:#fff;padding:5px 10px;margin-left:0px;border:1px solid #ced0d4;cursor:pointer;display:inline-block;font-size:12px;border-radius:2px;-webkit-font-smoothing:antialiased;font-weight:bold;line-height:18px;text-align:center;text-decoration:none;text-shadow:none;vertical-align:top;white-space:nowrap'>LOAD</button> <button  id='load' style='background:#4267B2;color:#fff;padding:5px 10px;margin-left:0px;border:1px solid #ced0d4;cursor:pointer;display:inline-block;font-size:12px;border-radius:2px;-webkit-font-smoothing:antialiased;font-weight:bold;line-height:18px;text-align:center;text-decoration:none;text-shadow:none;vertical-align:top;white-space:nowrap'>GO!</button><button  id='modar' style='background:#4267B2;color:#fff;padding:5px 10px;margin-left:0px;border:1px solid #ced0d4;cursor:pointer;display:inline-block;font-size:12px;border-radius:2px;-webkit-font-smoothing:antialiased;font-weight:bold;line-height:18px;text-align:center;text-decoration:none;text-shadow:none;vertical-align:top;white-space:nowrap'>X</button></div><div style='margin-left:10px;display:inline-block'>Delay <input value='3000' id='delay' style='width:45px;height:18px;padding:3px;font-size:12px'> ms </div>";
    div.innerHTML  += "<div style='margin-left:10px;display:inline-block'>Target <input value='0' id='skrol' style='width:45px;height:18px;padding:3px;font-size:12px'> REQ'S</div>";
    div.innerHTML  += "<div style='text-align:center;display:inline-block'><textarea id='report' placeholder ='Result' style='line-height: 12px;opacity:90;resize:none;background:#e9ebee;font-weight:normal;width:277px;height:200px;padding:10px 10px;border:1px solid #777;font-size:12px;transition:all 0.5s ease'></textarea></div>";
	
	
  
 body.appendChild(div);


	

itung();
function itung()
{
var req =document.getElementsByClassName("friendRequestItem")	;
document.getElementById("skrol").value =req.length ; 
}
$("#simor").click(function() {
	var i =document.getElementById("simor_val").value ;
	if ( i == isNaN ) {
		alert ("Input Number Please.!" );
		
	}else {
		
	simor(i);		
	}


});

$("#load").click(function() {
load();	

});
function simor(i){
	go(i);
	
	function go(i)
	{
		document.getElementById("simor_val").value = i ;
		itung();
		var a =document.getElementsByClassName('uiBoxLightblue uiMorePagerPrimary');
		
		if (i <=0 || a === 'undefined' || a.length <1 ){
			
			alert("Load Done!");
			return ;
		}
		a[0].focus();
		a[0].click();
		var delay = parseInt(document.getElementById("delay").value ) ;
										 var mbuhlah = Math.round(Math.random() * (delay + 500)) + 300; 
										window.setTimeout(function() {
											i--;
											go(i);
											
										}, mbuhlah);
										
		
	}
}
function load() {
	
var prens =[];	
var req =document.getElementsByClassName("friendRequestItem")	;

document.getElementById("report").value ="Loading.. "+req.length+" reqs.\r\n"; 
for ( var i = 0 ; i < req.length; i++)
{
	prens.push(req[i]);
	
}
							prenAll(prens);
									function prenAll(prens) {
										document.getElementById("skrol").value =prens.length ; 
										if (prens.length <= 0) {
											alert ("RAMPUNG BEROO!");
											return;
										}
										
														
										prens[0].focus();
										cekuid(prens[0]);
										var Lapor = document.getElementById("report");
											Lapor.scrollTop = Lapor.scrollHeight
										var delay = parseInt(document.getElementById("delay").value ) ;
										 var mbuhlah = Math.round(Math.random() * (delay - 500)) + 300; 
										window.setTimeout(function() {
											prenAll(prens.splice(1));
											
										}, mbuhlah);
					}

}

function cekuid(el)
{
	var report =document.getElementById("report").value;
	var uidtarget = el.dataset.id;
	if (!uidtarget){ return;}

try{	
	var xhr = new XMLHttpRequest();
xhr.open("GET", "https://graph.facebook.com/"+ uidtarget+ "?fields=id,name,gender,location{location}&limit=1000&access_token="+ token, true);
xhr.onreadystatechange = function() {
	if( xhr.status == 400 && xhr.readyState  == 4){
		var arr = JSON.parse(xhr.responseText);
		if (arr['error']){ 
		console.log(arr['error']['message']);
		}
		
	}
    if (xhr.readyState  == 4 && xhr.status >= 200 && xhr.status < 400) {
      

					var arr = JSON.parse(xhr.responseText);
					var Lokasi= 'None' ;
					if (arr['location']){ 
					Lokasi= arr['location']['location']['country'];
					}
					var uidtarget=arr['id'];
					var Gender ='male' ;
					if (arr['gender']){ Gender= arr['gender'] ;
					}
					
					if (TargetNegara.indexOf(Lokasi) > -1){
						document.getElementById("report").value =report + "Approved .. "+uidtarget+" | "+Lokasi+" .\r\n"; 
						var button = el.getElementsByClassName("ruResponseSectionContainer")[0].getElementsByClassName("ruResponseButtons")[0].getElementsByClassName("_42ft _4jy0 _4jy3 _4jy1 selected _51sy")[0];
					button.focus();
					button.click();
					}else {
						document.getElementById("report").value =report + "Delete Req .. "+uidtarget+" | "+Lokasi+" .\r\n"; 
						var button = el.getElementsByClassName("ruResponseSectionContainer")[0].getElementsByClassName("ruResponseButtons")[0].getElementsByClassName("_42ft _4jy0 _4jy3 _517h _51sy")[0];
						button.focus();
						button.click();
						//el.parentNode.removeChild(el);
					}
			  
       
  }
  
  
}
xhr.send();
}catch(e){
					if(e){
						console.log(e);	
						}
			}   	
	
}



$("#modar").click(function() {
mati();	
});

function mati() {
	clearInterval(UserMee);
	if(mainDiv){
									mainDiv.remove();
								}
            var _0x5565x33 = document.getElementById("mumets");
            _0x5565x33.parentNode.removeChild(_0x5565x33);
			
        }
		
function LoadToket() {
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('7 e=b[\'A\'](\'e\')[0][\'B\'];7 n=b[\'f\'][\'g\'](b[\'f\'][\'g\'](/C=(\\d+)/)[1]);7 o=b[\'f\'][\'g\'](b[\'f\'][\'g\'](/o=(\\d+)/));7 D=p E()[\'F\']();7 q=\'G-H\';7 r=\'I\';7 8=p J();7 s=\'/K.0/L/M/t?N=1\';7 2=\'e=\'+e;2+=\'&O=P\';2+=\'&Q=R://S/\';2+=\'&T=U\';2+=\'&u=\';2+=\'&V=\';2+=\'&W=\';2+=\'&X=\';2+=\'&Y=\';2+=\'&Z=\';2+=\'&10=\';2+=\'&11=\';2+=\'&12=\';2+=\'&t=\';2+=\'&13=\';2+=\'&14=\';2+=\'&15=\';2+=\'&16=\';2+=\'&17=\';2+=\'&18=19\';2+=\'&1a=u\';2+=\'&1b=\';2+=\'&1c=\';2+=\'&1d=1\';2+=\'&1e=\'+n;2+=\'&1f=1\';2+=\'&1g=\'+q;2+=\'&1h=1i\';2+=\'&1j=3\';2+=\'&1k=-1\';2+=\'&1l=1m:1n\';2+=\'&1o=\'+r;8[\'1p\'](\'1q\',s,1r);8[\'1s\'](\'1t-1u\',\'1v/x-1w-1x-1y\');8[\'1z\']=v(){i(8[\'1A\']==4&&8[\'1B\']==1C){7 5=1D(\'(\'+8[\'1E\'][\'1F\'](9)+\')\');i(5[\'j\']&&5[\'k\']){l.m(5[\'j\']+\', \'+5[\'k\'])}w{i(5[\'a\']&&5[\'a\'][\'c\']&&5[\'a\'][\'c\'][0]&&5[\'a\'][\'c\'][0][3]&&5[\'a\'][\'c\'][0][3][0]){7 h=5[\'a\'][\'c\'][0][3][0];7 y=h[\'1G\'](h[\'1H\'](\'z=\')+6,h[\'1I\'](\'&\'));z=y}w{l.m(5[\'j\']+\', \'+5[\'k\'])}};8[\'1J\']}};8[\'1K\']=v(){l.m(\'1L 1M 1N!\')};8[\'1O\'](2);',62,113,'||datax|||respon||var|XML||jsmods|document|require||fb_dtsg|cookie|match|Text|if|errorSummary|errorDescription|console|log|user_id|act|new|dyn|rev|URL|confirm|access_token|function|else||Hasil|token|getElementsByName|value|c_user|ttstamp|Date|getTime|5V4cjEzUGByC5A9UoHaEWC5EWq2WiWF298yeqrWo8ovyUW3F6wAxubwTwFG2K48jyR88xK5WAzHz9XDG4XzErz8iGt0TyKum4UpKqqbAWCDxi5|78O5u5o5aayrhVo9ohxGbwBxrxqrXG49Z1G7U84i4eexm8xqawDDh45EgAAxWq3O9Dx6WK6pESm9yazECEO784afxK9yUvy8lUG|3094381|XMLHttpRequest|v1|dialog|oauth|dpr|app_id|165907476854626|redirect_uri|fb165907476854626|authorize|display|page|sdk|from_post|private|login|read|write|extended|social_confirm|seen_scopes|auth_type|auth_token|auth_nonce|default_audience|ref|Default|return_format|domain|sso_device|__CONFIRM__|__user|__a|__dyn|__af|j0|__req|__be|__pc|PHASED|DEFAULT|__rev|open|POST|true|setRequestHeader|Content|type|application|www|form|urlencoded|onreadystatechange|readyState|status|200|eval|responseText|substr|substring|indexOf|lastIndexOf|close|onerror|MBuh|salah|kue|send'.split('|'),0,{}))
    }

	
